-- file: ch12/Barcode.hs
type Map a = M.Map Digit [a]