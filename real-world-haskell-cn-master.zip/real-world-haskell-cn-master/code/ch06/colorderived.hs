-- file: ch06/colorderived.hs
data Color = Red | Green | Blue
             deriving (Read, Show, Eq, Ord)