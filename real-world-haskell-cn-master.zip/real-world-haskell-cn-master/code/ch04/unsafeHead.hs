-- file ch04/unsafeHead.hs
unsafeHead = \(x:_) -> x
