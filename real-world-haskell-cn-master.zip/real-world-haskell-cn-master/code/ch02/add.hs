-- file: ch02/add.hs
add a b = a + b
