-- file: ch02/isOdd.hs
isOdd n = mod n 2 == 1
