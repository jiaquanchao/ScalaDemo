-- file: ch02/Assign.hs
x = 10
x = 11
