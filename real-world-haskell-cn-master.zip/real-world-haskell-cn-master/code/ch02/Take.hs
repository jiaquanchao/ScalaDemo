-- file: ch02/Take.hs
take :: Int -> ([a] -> [a])
