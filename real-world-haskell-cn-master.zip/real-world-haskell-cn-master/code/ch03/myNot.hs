-- file: ch03/myNot.hs
myNot True = False
myNot False = True
