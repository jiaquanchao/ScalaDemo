-- file: ch03/Bool.hs
data Bool = False | True
