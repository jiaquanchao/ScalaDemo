-- file: ch03/complicated.hs
complicated (True, a, x:xs, 5) = (a, xs)
