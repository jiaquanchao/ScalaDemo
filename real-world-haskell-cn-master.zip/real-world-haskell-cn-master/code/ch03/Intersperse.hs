-- file: ch03/Intersperse.hs
intersperse :: a -> [[a]] -> [a]
