-- file: ch03/third.hs
third (a, b, c) = c
